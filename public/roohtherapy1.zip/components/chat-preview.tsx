"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Send } from "lucide-react"
import { motion } from "framer-motion"

export default function ChatPreview() {
  const [messages, setMessages] = useState([
    {
      isUser: false,
      text: "Hello there! How are you feeling today? Remember, this is a safe space.",
      time: "10:03 AM",
    },
  ])
  const [input, setInput] = useState("")

  const handleSend = () => {
    if (!input.trim()) return

    // Add user message
    setMessages((prev) => [
      ...prev,
      {
        isUser: true,
        text: input,
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ])
    setInput("")

    // Simulate therapist response after 1 second
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          isUser: false,
          text: "Thank you for sharing. It's completely normal to feel that way. Would you like to explore why you might be experiencing these emotions?",
          time: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
        },
      ])
    }, 1000)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="rounded-2xl shadow-card overflow-hidden bg-card border border-border theme-transition"
    >
      <div className="bg-gradient-to-r from-primary to-primary/90 px-6 py-4">
        <h3 className="text-primary-foreground text-lg font-medium">Secure Anonymous Chat</h3>
        <p className="text-primary-foreground/80 text-sm">Connect with a certified therapist</p>
      </div>

      <div className="h-64 p-4 overflow-y-auto bg-background/50">
        {messages.map((message, index) => (
          <div key={index} className={`mb-4 flex ${message.isUser ? "justify-end" : "justify-start"}`}>
            <div
              className={`max-w-[80%] p-3 rounded-lg ${
                message.isUser
                  ? "bg-primary text-primary-foreground rounded-tr-none"
                  : "bg-card border border-border text-foreground rounded-tl-none"
              }`}
            >
              <p className="text-sm">{message.text}</p>
              <p className={`text-xs mt-1 ${message.isUser ? "text-primary-foreground/70" : "text-foreground/60"}`}>
                {message.time}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-border bg-card">
        <div className="flex">
          <input
            type="text"
            placeholder="Type your message..."
            className="flex-1 bg-background border border-border rounded-l-lg px-4 py-2 text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") handleSend()
            }}
          />
          <Button
            className="rounded-l-none bg-primary hover:bg-primary-light text-primary-foreground"
            onClick={handleSend}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  )
}
