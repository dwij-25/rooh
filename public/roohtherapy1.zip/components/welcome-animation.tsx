"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { Leaf, Heart, Sparkles, Star } from "lucide-react"

export default function WelcomeAnimation() {
  const [show, setShow] = useState(true)
  const [phase, setPhase] = useState(1)
  const particlesRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // Phase 1: Initial animation
    const phase1Timer = setTimeout(() => {
      setPhase(2)
    }, 2000)

    // Phase 2: Logo and text appear
    const phase2Timer = setTimeout(() => {
      setPhase(3)
    }, 3500)

    // Phase 3: Final animation before exit
    const phase3Timer = setTimeout(() => {
      setShow(false)
    }, 5000)

    return () => {
      clearTimeout(phase1Timer)
      clearTimeout(phase2Timer)
      clearTimeout(phase3Timer)
    }
  }, [])

  // Create particles effect
  useEffect(() => {
    if (!particlesRef.current || phase !== 3) return

    const container = particlesRef.current
    const particles = 20

    // Clear any existing particles
    container.innerHTML = ""

    for (let i = 0; i < particles; i++) {
      const particle = document.createElement("div")
      particle.className = "absolute rounded-full"

      // Randomize properties
      const size = Math.random() * 8 + 4
      const color = i % 2 === 0 ? "bg-primary" : "bg-accent"
      const left = Math.random() * 100
      const delay = Math.random() * 0.5

      particle.style.width = `${size}px`
      particle.style.height = `${size}px`
      particle.classList.add(color, "opacity-70")
      particle.style.left = `${left}%`
      particle.style.top = "50%"

      // Animation
      particle.animate(
        [
          { transform: "translate(-50%, -50%) scale(0)", opacity: 0 },
          { transform: `translate(-50%, -${50 + Math.random() * 100}%) scale(1)`, opacity: 0.7 },
          { transform: `translate(-50%, -${100 + Math.random() * 150}%) scale(0)`, opacity: 0 },
        ],
        {
          duration: 1500 + Math.random() * 1000,
          delay: delay * 1000,
          easing: "cubic-bezier(0.4, 0, 0.2, 1)",
          fill: "forwards",
        },
      )

      container.appendChild(particle)
    }
  }, [phase])

  if (!show) return null

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-background welcome-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
        >
          {/* Background gradient animation */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/10"
            animate={{
              background: [
                "linear-gradient(to right, rgba(131, 135, 195, 0.1), rgba(149, 155, 181, 0.1))",
                "linear-gradient(to right, rgba(149, 155, 181, 0.1), rgba(131, 135, 195, 0.1))",
                "linear-gradient(to right, rgba(131, 135, 195, 0.1), rgba(149, 155, 181, 0.1))",
              ],
            }}
            transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "easeInOut" }}
          />

          {/* Animated particles container */}
          <div ref={particlesRef} className="absolute inset-0 overflow-hidden pointer-events-none" />

          {/* Animated shapes */}
          <div className="absolute inset-0 overflow-hidden">
            {phase >= 1 && (
              <>
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="absolute"
                    initial={{
                      top: `${Math.random() * 100}%`,
                      left: `${Math.random() * 100}%`,
                      opacity: 0,
                      scale: 0,
                    }}
                    animate={{
                      opacity: [0, 0.7, 0],
                      scale: [0, 1, 0],
                      y: [0, -50, -100],
                    }}
                    transition={{
                      duration: 3 + Math.random() * 2,
                      repeat: Number.POSITIVE_INFINITY,
                      delay: Math.random() * 2,
                      ease: "easeInOut",
                    }}
                  >
                    {i % 4 === 0 && <Leaf className="text-primary/30 w-8 h-8" />}
                    {i % 4 === 1 && <Heart className="text-accent/30 w-6 h-6" />}
                    {i % 4 === 2 && <Sparkles className="text-secondary/30 w-7 h-7" />}
                    {i % 4 === 3 && <Star className="text-primary/30 w-5 h-5" />}
                  </motion.div>
                ))}
              </>
            )}
          </div>

          <div className="relative flex flex-col items-center z-10">
            {/* Enhanced animated leaves with better positioning and animations */}
            {phase >= 2 && (
              <div className="absolute w-full h-full">
                <motion.div
                  className="absolute -top-24 -left-24"
                  initial={{ scale: 0, opacity: 0, rotate: -15 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{
                    duration: 1,
                    type: "spring",
                    stiffness: 100,
                  }}
                >
                  <Leaf className="h-12 w-12 text-primary filter drop-shadow-lg" />
                </motion.div>
                <motion.div
                  className="absolute -top-16 left-16"
                  initial={{ scale: 0, opacity: 0, rotate: 15 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{
                    delay: 0.1,
                    duration: 1,
                    type: "spring",
                    stiffness: 100,
                  }}
                >
                  <Leaf className="h-10 w-10 text-accent filter drop-shadow-lg" />
                </motion.div>
                <motion.div
                  className="absolute top-12 -left-20"
                  initial={{ scale: 0, opacity: 0, rotate: -20 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{
                    delay: 0.2,
                    duration: 1,
                    type: "spring",
                    stiffness: 100,
                  }}
                >
                  <Leaf className="h-8 w-8 text-secondary filter drop-shadow-lg" />
                </motion.div>
                <motion.div
                  className="absolute -top-20 -right-16"
                  initial={{ scale: 0, opacity: 0, rotate: 20 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{
                    delay: 0.3,
                    duration: 1,
                    type: "spring",
                    stiffness: 100,
                  }}
                >
                  <Leaf className="h-11 w-11 text-primary filter drop-shadow-lg" />
                </motion.div>
                <motion.div
                  className="absolute top-12 -right-14"
                  initial={{ scale: 0, opacity: 0, rotate: -15 }}
                  animate={{ scale: 1, opacity: 1, rotate: 0 }}
                  transition={{
                    delay: 0.4,
                    duration: 1,
                    type: "spring",
                    stiffness: 100,
                  }}
                >
                  <Leaf className="h-9 w-9 text-accent filter drop-shadow-lg" />
                </motion.div>
              </div>
            )}

            {/* Logo with enhanced animation */}
            {phase >= 2 && (
              <motion.div
                className="welcome-logo mb-6 flex items-center"
                initial={{ scale: 0.8, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                transition={{
                  duration: 1.2,
                  type: "spring",
                  stiffness: 100,
                }}
              >
                <motion.div
                  className="h-28 w-28 relative mb-2 filter drop-shadow-xl"
                  animate={{
                    scale: [1, 1.05, 1],
                    rotate: [0, 2, 0, -2, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                >
                  <Image src="/logo.png" alt="ROOH Logo" fill className="object-contain" priority />
                </motion.div>
                <motion.span
                  className="text-6xl font-bold ml-3 text-shadow"
                  animate={{
                    textShadow: ["0 2px 4px rgba(0,0,0,0.2)", "0 4px 8px rgba(0,0,0,0.3)", "0 2px 4px rgba(0,0,0,0.2)"],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    ease: "easeInOut",
                  }}
                >
                  <span className="text-primary">R</span>
                  <span className="text-foreground">OOH</span>
                </motion.span>
              </motion.div>
            )}

            {/* Enhanced tagline with sparkle effect */}
            {phase >= 2 && (
              <motion.div
                className="relative"
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.3, duration: 1, type: "spring", stiffness: 100 }}
              >
                <motion.p className="welcome-text text-xl text-foreground/80 font-medium tracking-wide">
                  A safe space to heal and grow
                </motion.p>

                {/* Sparkle effects */}
                <motion.div
                  className="absolute -top-1 -left-4"
                  animate={{
                    opacity: [0, 1, 0],
                    scale: [0.8, 1.2, 0.8],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    delay: 0.5,
                    ease: "easeInOut",
                  }}
                >
                  <Sparkles className="h-4 w-4 text-primary" />
                </motion.div>

                <motion.div
                  className="absolute -bottom-1 -right-4"
                  animate={{
                    opacity: [0, 1, 0],
                    scale: [0.8, 1.2, 0.8],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    delay: 1,
                    ease: "easeInOut",
                  }}
                >
                  <Sparkles className="h-4 w-4 text-accent" />
                </motion.div>
              </motion.div>
            )}
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
