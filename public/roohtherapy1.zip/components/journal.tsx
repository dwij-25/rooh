"use client"

import { Button } from "@/components/ui/button"
import { BookOpen, Plus, Calendar } from "lucide-react"
import { motion } from "framer-motion"

export default function Journal() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="rounded-2xl shadow-card overflow-hidden bg-card border border-border"
    >
      <div className="bg-gradient-to-r from-primary to-primary-dark px-6 py-4">
        <h3 className="text-white text-lg font-medium">Emotion Journal</h3>
        <p className="text-slate-200 text-sm">Express yourself privately and safely</p>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h4 className="text-lg font-medium text-card-foreground">Recent Entries</h4>
          <Button className="bg-primary hover:bg-primary-light">
            <Plus className="h-4 w-4 mr-2" />
            New Entry
          </Button>
        </div>

        <div className="space-y-4">
          {[
            {
              date: "Apr 15, 2025",
              title: "Finding My Center",
              excerpt:
                "Today I practiced the mindfulness exercise and felt a moment of peace for the first time in weeks...",
            },
            {
              date: "Apr 10, 2025",
              title: "Social Anxiety at Work",
              excerpt: "The team meeting was overwhelming today. I felt my heart racing when I had to speak up...",
            },
            {
              date: "Apr 5, 2025",
              title: "Small Victory",
              excerpt: "I managed to call to schedule an appointment without rehearsing what to say first...",
            },
          ].map((entry, index) => (
            <div
              key={index}
              className="p-4 border border-border rounded-lg hover:border-primary/50 hover:bg-background/50 transition-colors cursor-pointer hover-lift"
            >
              <div className="flex items-center mb-2">
                <Calendar className="w-4 h-4 text-primary mr-2" />
                <span className="text-sm text-card-foreground/70">{entry.date}</span>
              </div>
              <h5 className="font-medium text-card-foreground mb-1">{entry.title}</h5>
              <p className="text-sm text-card-foreground/80 line-clamp-2">{entry.excerpt}</p>
            </div>
          ))}
        </div>

        <div className="mt-6 text-center">
          <Button variant="ghost" className="text-primary hover:text-primary-light hover:bg-primary/10">
            <BookOpen className="h-4 w-4 mr-2" />
            View All Entries
          </Button>
        </div>
      </div>
    </motion.div>
  )
}
