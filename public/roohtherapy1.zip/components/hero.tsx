"use client"

import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { useTheme } from "next-themes"
import { Leaf, ArrowRight, Heart, Sparkles } from "lucide-react"
import Link from "next/link"

const phrases = [
  "Find peace in anonymity.",
  "Be heard without being seen.",
  "Connect without revealing.",
  "Heal in your safe space.",
  "Your emotions matter.",
]

export default function Hero() {
  const [phrase, setPhrase] = useState(phrases[0])
  const [index, setIndex] = useState(0)
  const { theme } = useTheme()

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prevIndex) => {
        const newIndex = (prevIndex + 1) % phrases.length
        setPhrase(phrases[newIndex])
        return newIndex
      })
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center pt-20 pb-24 md:pt-32 md:pb-40 bg-dark-gradient overflow-hidden theme-transition">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] bg-cover bg-center opacity-5"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-background via-background/95 to-background"></div>
      </div>

      {/* Enhanced animated gradient orbs with more subtle movement */}
      <motion.div
        className="absolute top-1/4 left-1/4 w-72 h-72 rounded-full bg-primary/15 blur-3xl"
        animate={{
          scale: [1, 1.1, 1],
          opacity: [0.3, 0.4, 0.3],
          x: [0, 20, 0],
          y: [0, -20, 0],
        }}
        transition={{
          duration: 10,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />
      <motion.div
        className="absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-secondary/15 blur-3xl"
        animate={{
          scale: [1, 1.15, 1],
          opacity: [0.2, 0.3, 0.2],
          x: [0, -30, 0],
          y: [0, 30, 0],
        }}
        transition={{
          duration: 12,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
          delay: 1,
        }}
      />

      {/* Enhanced floating elements - more minimal but with better animation */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute"
            style={{
              top: `${20 + i * 10}%`,
              left: `${10 + i * 15}%`,
            }}
            animate={{
              y: [0, -15, 0],
              x: [0, 15, 0],
              rotate: [0, 5, 0, -5, 0],
              opacity: [0.2, 0.3, 0.2],
            }}
            transition={{
              duration: 8 + i,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
              delay: i * 0.5,
            }}
          >
            {i % 3 === 0 && <Leaf className="text-primary/20 w-10 h-10" />}
            {i % 3 === 1 && <Heart className="text-accent/20 w-8 h-8" />}
            {i % 3 === 2 && <Sparkles className="text-secondary/20 w-9 h-9" />}
          </motion.div>
        ))}
      </div>

      <div className="container px-4 mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto"
        >
          <motion.h1
            className="text-4xl md:text-6xl font-bold text-foreground leading-tight mb-6"
            animate={{
              textShadow: ["0 2px 4px rgba(0,0,0,0.1)", "0 3px 6px rgba(0,0,0,0.2)", "0 2px 4px rgba(0,0,0,0.1)"],
            }}
            transition={{
              duration: 4,
              repeat: Number.POSITIVE_INFINITY,
              ease: "easeInOut",
            }}
          >
            A Safe Space for <span className="gradient-text">Introverts</span> to Heal and Grow
          </motion.h1>
          <div className="h-12 mb-6 overflow-hidden">
            <motion.p
              key={phrase}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.5 }}
              className="text-xl md:text-2xl text-foreground/90 mb-8"
            >
              {phrase}
            </motion.p>
          </div>
          <motion.p
            className="text-foreground/80 text-lg max-w-3xl mx-auto mb-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            Experience anonymous therapy, emotional tracking, and community support – all designed with your privacy and
            comfort in mind.
          </motion.p>
          <motion.div
            className="flex flex-col sm:flex-row justify-center gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.8 }}
          >
            <Link href="#features">
              <Button className="text-lg px-8 py-6 bg-primary hover:bg-primary-light shadow-glow text-primary-foreground group transition-all duration-300 transform hover:scale-105 relative overflow-hidden">
                <motion.span
                  className="absolute inset-0 bg-white/10 rounded-md"
                  initial={{ x: "-100%", opacity: 0 }}
                  whileHover={{ x: "100%", opacity: 0.3 }}
                  transition={{ duration: 0.6 }}
                />
                Start Your Journey
                <ArrowRight className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Button>
            </Link>
            <Link href="#how-it-works">
              <Button
                variant="outline"
                className="text-lg px-8 py-6 text-foreground border-primary hover:bg-primary/10 group transition-all duration-300 transform hover:scale-105 relative overflow-hidden"
              >
                <motion.span
                  className="absolute inset-0 bg-primary/5 rounded-md"
                  initial={{ scale: 0, opacity: 0 }}
                  whileHover={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.4 }}
                />
                How It Works
                <Heart className="ml-2 h-5 w-5 transition-transform duration-300 group-hover:scale-110" />
              </Button>
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}
