"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Trophy, Star, Calendar, BookOpen, Heart } from "lucide-react"
import { Button } from "@/components/ui/button"

type Milestone = {
  id: string
  title: string
  description: string
  icon: React.ReactNode
  completed: boolean
  progress: number
}

export default function ProgressIndicator() {
  const [milestones, setMilestones] = useState<Milestone[]>([
    {
      id: "first-mood",
      title: "First Mood Log",
      description: "Track your first emotional state",
      icon: <Heart className="h-5 w-5 text-accent" />,
      completed: false,
      progress: 0,
    },
    {
      id: "journal-entry",
      title: "Journal Reflection",
      description: "Write your first journal entry",
      icon: <BookOpen className="h-5 w-5 text-primary" />,
      completed: false,
      progress: 0,
    },
    {
      id: "week-streak",
      title: "Week Streak",
      description: "Log your mood for 7 consecutive days",
      icon: <Calendar className="h-5 w-5 text-secondary" />,
      completed: false,
      progress: 0,
    },
    {
      id: "community",
      title: "Community Connection",
      description: "Make your first community post or comment",
      icon: <Star className="h-5 w-5 text-accent" />,
      completed: false,
      progress: 0,
    },
  ])

  // Simulate progress for demo purposes
  useEffect(() => {
    // In a real app, this would be fetched from an API or local storage
    const simulatedProgress = {
      "first-mood": { completed: true, progress: 100 },
      "journal-entry": { completed: false, progress: 0 },
      "week-streak": { completed: false, progress: 28 }, // 2/7 days
      community: { completed: false, progress: 50 }, // Started but not completed
    }

    setMilestones((prev) =>
      prev.map((milestone) => ({
        ...milestone,
        completed: simulatedProgress[milestone.id as keyof typeof simulatedProgress].completed,
        progress: simulatedProgress[milestone.id as keyof typeof simulatedProgress].progress,
      })),
    )
  }, [])

  return (
    <div className="bg-card rounded-2xl shadow-card border border-border p-6" id="progress-tracker">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-medium text-foreground">Your Progress</h3>
          <p className="text-foreground/70 text-sm">Track your healing journey</p>
        </div>
        <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/20">
          <Trophy className="h-6 w-6 text-primary" />
        </div>
      </div>

      <div className="space-y-4">
        {milestones.map((milestone) => (
          <div key={milestone.id} className="relative">
            <div className="flex items-center mb-2">
              <div
                className={`flex items-center justify-center w-8 h-8 rounded-full mr-3 ${
                  milestone.completed ? "bg-primary" : "bg-primary/20"
                }`}
              >
                {milestone.icon}
              </div>
              <div>
                <h4 className="text-foreground font-medium">{milestone.title}</h4>
                <p className="text-foreground/70 text-sm">{milestone.description}</p>
              </div>
              {milestone.completed && (
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="ml-auto bg-primary/20 text-primary text-xs font-medium px-2 py-1 rounded-full"
                >
                  Completed
                </motion.div>
              )}
            </div>

            <div className="h-2 bg-background rounded-full overflow-hidden ml-11">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${milestone.progress}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full bg-primary rounded-full"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 text-center">
        <Button variant="outline" className="text-primary border-primary hover:bg-primary/10">
          View All Milestones
        </Button>
      </div>
    </div>
  )
}
