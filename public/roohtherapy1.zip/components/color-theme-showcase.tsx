"use client"

import { motion } from "framer-motion"
import { useTheme } from "next-themes"

export default function ColorThemeShowcase() {
  const { theme } = useTheme()

  // Updated dark colors to match the new blue/purple palette
  const darkColors = [
    { hex: "#0A1123", name: "Dark Blue" },
    { hex: "#3A3E6C", name: "Indigo" },
    { hex: "#8387C3", name: "Lavender" },
    { hex: "#8A8CAC", name: "Muted Lavender" },
    { hex: "#959BB5", name: "Blue Gray" },
  ]

  const lightColors = [
    { hex: "#B86B4B", name: "Terracotta" },
    { hex: "#EBDACF", name: "Cream" },
    { hex: "#F5EEE7", name: "Off-White" },
    { hex: "#D9A684", name: "Light Brown" },
    { hex: "#603B2B", name: "Dark Brown" },
  ]

  const colors = theme === "dark" ? darkColors : lightColors

  return (
    <section className="py-16 bg-background border-y border-border theme-transition">
      <div className="container mx-auto px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-3xl font-bold text-foreground mb-8 text-center"
        >
          Our <span className="gradient-text">Elegant</span> Color Palette
        </motion.h2>

        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="grid grid-cols-2 md:grid-cols-5 gap-4 max-w-3xl mx-auto"
        >
          {colors.map((color, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: 0.1 * index }}
              className="flex flex-col items-center"
            >
              <div
                className="w-full h-24 rounded-lg shadow-card mb-2 hover-lift"
                style={{ backgroundColor: color.hex }}
              ></div>
              <span className="text-sm font-medium text-foreground">{color.hex}</span>
              <span className="text-xs text-foreground/60">{color.name}</span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
