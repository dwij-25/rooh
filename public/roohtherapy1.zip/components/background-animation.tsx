"use client"

import { useEffect, useRef, useState } from "react"
import { useTheme } from "next-themes"

interface Particle {
  x: number
  y: number
  size: number
  speedX: number
  speedY: number
  color: string
  opacity: number
  rotation: number
  rotationSpeed: number
  shape: string
  pulseSpeed: number
  pulseSize: number
}

export default function BackgroundAnimation() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const { theme } = useTheme()
  const [particles, setParticles] = useState<Particle[]>([])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas to full screen
    const setCanvasSize = () => {
      canvas.width = window.innerWidth
      canvas.height = window.innerHeight
    }

    setCanvasSize()
    window.addEventListener("resize", setCanvasSize)

    // Colors based on theme with more vibrant options for dark mode
    const darkColors = ["#8387C3", "#9D9FD2", "#7A7CC8", "#6A6CB8", "#5A5CA8"]
    const lightColors = ["#B86B4B", "#C87C5C", "#D88C6C", "#E89C7C", "#F8AC8C"]

    const colors = theme === "dark" ? darkColors : lightColors
    const shapes = ["leaf", "circle", "square", "triangle", "diamond"]

    // Create particles with more variety but keep it minimal
    const newParticles: Particle[] = []
    const particleCount = Math.min(window.innerWidth / 12, 80) // Fewer particles for minimalism

    for (let i = 0; i < particleCount; i++) {
      const size = Math.random() * 5 + 2 // Smaller sizes for minimalism
      newParticles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size,
        speedX: (Math.random() - 0.5) * 0.4, // Slower for subtlety
        speedY: (Math.random() - 0.5) * 0.4,
        color: colors[Math.floor(Math.random() * colors.length)],
        opacity: Math.random() * 0.3 + 0.05, // More transparent for subtlety
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 0.6,
        shape: shapes[Math.floor(Math.random() * shapes.length)],
        pulseSpeed: Math.random() * 0.02 + 0.01,
        pulseSize: Math.random() * 0.3 + 0.9,
      })
    }

    setParticles(newParticles)

    // Animation loop with improved drawing
    let animationFrameId: number
    let time = 0
    const animate = () => {
      time += 0.01
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw particles
      setParticles((prevParticles) =>
        prevParticles.map((particle) => {
          // Update position with slight sine wave movement for more organic feel
          particle.x += particle.speedX + Math.sin(time * 2) * 0.1
          particle.y += particle.speedY + Math.cos(time * 2) * 0.1
          particle.rotation += particle.rotationSpeed

          // Pulse size for subtle breathing effect
          const pulseFactor = Math.sin(time * particle.pulseSpeed * 10) * 0.2 + 1
          const currentSize = particle.size * particle.pulseSize * pulseFactor

          // Bounce off edges with slight dampening for natural feel
          if (particle.x < 0 || particle.x > canvas.width) {
            particle.speedX *= -0.95
            particle.x = particle.x < 0 ? 0 : canvas.width
          }
          if (particle.y < 0 || particle.y > canvas.height) {
            particle.speedY *= -0.95
            particle.y = particle.y < 0 ? 0 : canvas.height
          }

          // Draw shape based on particle.shape with subtle glow
          ctx.save()
          ctx.translate(particle.x, particle.y)
          ctx.rotate((particle.rotation * Math.PI) / 180)
          ctx.globalAlpha = particle.opacity

          // Add subtle glow
          ctx.shadowColor = particle.color
          ctx.shadowBlur = 5
          ctx.fillStyle = particle.color

          switch (particle.shape) {
            case "leaf":
              // Draw a leaf shape
              ctx.beginPath()
              ctx.ellipse(0, 0, currentSize * 2, currentSize, 0, 0, Math.PI * 2)
              ctx.fill()
              break
            case "circle":
              // Draw a circle
              ctx.beginPath()
              ctx.arc(0, 0, currentSize, 0, Math.PI * 2)
              ctx.fill()
              break
            case "square":
              // Draw a square
              ctx.fillRect(-currentSize, -currentSize, currentSize * 2, currentSize * 2)
              break
            case "triangle":
              // Draw a triangle
              ctx.beginPath()
              ctx.moveTo(0, -currentSize)
              ctx.lineTo(currentSize, currentSize)
              ctx.lineTo(-currentSize, currentSize)
              ctx.closePath()
              ctx.fill()
              break
            case "diamond":
              // Draw a diamond
              ctx.beginPath()
              ctx.moveTo(0, -currentSize * 1.5)
              ctx.lineTo(currentSize, 0)
              ctx.lineTo(0, currentSize * 1.5)
              ctx.lineTo(-currentSize, 0)
              ctx.closePath()
              ctx.fill()
              break
          }

          ctx.restore()

          return particle
        }),
      )

      animationFrameId = requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", setCanvasSize)
      cancelAnimationFrame(animationFrameId)
    }
  }, [theme])

  return <canvas ref={canvasRef} className="fixed top-0 left-0 w-full h-full -z-10" />
}
