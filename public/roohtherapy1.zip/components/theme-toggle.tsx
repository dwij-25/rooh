"use client"

import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { Moon, Sun, Stars } from "lucide-react"
import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  // Avoid hydration mismatch by only rendering after mount
  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <Button variant="ghost" size="icon" className="w-9 h-9 opacity-0">
        <Sun className="h-4 w-4" />
      </Button>
    )
  }

  const isDark = theme === "dark"

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={() => setTheme(isDark ? "light" : "dark")}
      className="w-10 h-10 rounded-full transition-colors relative overflow-hidden"
      aria-label="Toggle theme"
    >
      {/* Background animation */}
      <motion.div
        className="absolute inset-0 rounded-full"
        animate={{
          backgroundColor: isDark ? "rgba(131, 135, 195, 0.1)" : "rgba(184, 107, 75, 0.1)",
        }}
        transition={{ duration: 0.5 }}
      />

      {/* Sun/Moon container with 3D rotation */}
      <motion.div
        initial={false}
        animate={{
          rotateY: isDark ? 180 : 0,
        }}
        transition={{
          duration: 0.6,
          type: "spring",
          stiffness: 100,
          damping: 15,
        }}
        style={{ transformStyle: "preserve-3d" }}
        className="relative w-full h-full flex items-center justify-center"
      >
        {/* Sun (front side) */}
        <motion.div
          style={{ backfaceVisibility: "hidden" }}
          className="absolute inset-0 flex items-center justify-center"
          animate={{
            scale: isDark ? 0.8 : 1,
            opacity: isDark ? 0 : 1,
          }}
          transition={{ duration: 0.3 }}
        >
          <Sun className="h-5 w-5 text-[#B86B4B]" />
        </motion.div>

        {/* Moon (back side) */}
        <motion.div
          style={{
            backfaceVisibility: "hidden",
            transform: "rotateY(180deg)",
          }}
          className="absolute inset-0 flex items-center justify-center"
          animate={{
            scale: isDark ? 1 : 0.8,
            opacity: isDark ? 1 : 0,
          }}
          transition={{ duration: 0.3 }}
        >
          <Moon className="h-5 w-5 text-[#8387C3]" />
        </motion.div>
      </motion.div>

      {/* Stars that appear in dark mode */}
      <AnimatePresence>
        {isDark && (
          <>
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0 }}
                transition={{ delay: 0.1 * i, duration: 0.3 }}
                style={{
                  top: `${20 + i * 20}%`,
                  left: `${20 + i * 20}%`,
                  transformOrigin: "center",
                }}
              >
                <Stars className="h-2 w-2 text-[#8387C3]" />
              </motion.div>
            ))}
          </>
        )}
      </AnimatePresence>
    </Button>
  )
}
