"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Calendar, Smile, Meh, Frown, AlarmClock, BarChart } from "lucide-react"
import { motion } from "framer-motion"

const emotions = [
  {
    name: "Happy",
    icon: Smile,
    color: "bg-lavender/30 text-lavender",
    description: "Feeling good, positive, or content",
  },
  {
    name: "Neutral",
    icon: Meh,
    color: "bg-blueGray/30 text-blueGray",
    description: "Neither particularly good nor bad",
  },
  {
    name: "Sad",
    icon: Frown,
    color: "bg-mutedLavender/30 text-mutedLavender",
    description: "Feeling down, blue, or unhappy",
  },
  {
    name: "Anxious",
    icon: AlarmClock,
    color: "bg-primary/30 text-primary",
    description: "Feeling worried, nervous, or uneasy",
  },
]

export default function MoodTracker() {
  const [selectedEmotion, setSelectedEmotion] = useState<number | null>(null)
  const [note, setNote] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would submit to an API or local storage
    alert(`Mood logged: ${selectedEmotion !== null ? emotions[selectedEmotion].name : "None"}\nNote: ${note}`)
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="rounded-2xl shadow-card overflow-hidden bg-card border border-border h-full"
    >
      <div className="bg-gradient-to-r from-primary to-primary-dark px-6 py-4">
        <h3 className="text-white text-lg font-medium">Mood Tracker</h3>
        <p className="text-slate-200 text-sm">How are you feeling right now?</p>
      </div>

      <form onSubmit={handleSubmit} className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center">
            <Calendar className="w-5 h-5 text-primary mr-2" aria-hidden="true" />
            <span className="text-card-foreground">Today, {new Date().toLocaleDateString()}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="text-primary hover:text-primary-light hover:bg-primary/10"
            type="button"
            aria-label="View mood history"
          >
            <BarChart className="w-4 h-4 mr-2" aria-hidden="true" />
            View History
          </Button>
        </div>

        <fieldset className="mb-6">
          <legend className="sr-only">Select your current mood</legend>
          <div className="grid grid-cols-2 gap-4">
            {emotions.map((emotion, index) => (
              <button
                key={index}
                type="button"
                className={`flex flex-col items-center justify-center p-4 rounded-lg border ${
                  selectedEmotion === index
                    ? "border-primary bg-primary/10"
                    : "border-border hover:border-primary/50 hover:bg-background/50"
                } transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background`}
                onClick={() => setSelectedEmotion(index)}
                aria-pressed={selectedEmotion === index}
                aria-label={`Feeling ${emotion.name}: ${emotion.description}`}
              >
                <div
                  className={`w-12 h-12 rounded-full ${emotion.color} flex items-center justify-center mb-2`}
                  aria-hidden="true"
                >
                  <emotion.icon className="w-6 h-6" />
                </div>
                <span className="text-card-foreground">{emotion.name}</span>
              </button>
            ))}
          </div>
        </fieldset>

        <div className="border-t border-border pt-4">
          <label htmlFor="moodNote" className="block text-sm font-medium text-card-foreground mb-2">
            Add a note (optional)
          </label>
          <textarea
            id="moodNote"
            rows={2}
            className="w-full p-2 bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 mb-4 text-foreground"
            placeholder="What's contributing to your mood today?"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            aria-describedby="noteHint"
          ></textarea>
          <p id="noteHint" className="sr-only">
            Describe what might be contributing to your mood today
          </p>

          <Button
            className="w-full bg-primary hover:bg-primary-light"
            type="submit"
            disabled={selectedEmotion === null}
            aria-disabled={selectedEmotion === null}
          >
            Log Your Mood
          </Button>
        </div>
      </form>
    </motion.div>
  )
}
