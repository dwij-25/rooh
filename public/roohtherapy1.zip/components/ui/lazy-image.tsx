"use client"

import { useState, useEffect } from "react"
import Image, { type ImageProps } from "next/image"

interface LazyImageProps extends Omit<ImageProps, "onLoad"> {
  lowQualitySrc?: string
  threshold?: number
}

export default function LazyImage({ src, alt, lowQualitySrc, threshold = 0.1, className, ...props }: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [isInView, setIsInView] = useState(false)

  useEffect(() => {
    if (!window.IntersectionObserver) {
      setIsInView(true)
      return
    }

    const element = document.querySelector(
      `[data-image-id="${props.id || Math.random().toString(36).substring(2, 9)}"]`,
    )
    if (!element) {
      setIsInView(true)
      return
    }

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsInView(true)
            observer.disconnect()
          }
        })
      },
      { threshold },
    )

    observer.observe(element)

    return () => {
      observer.disconnect()
    }
  }, [props.id, threshold])

  return (
    <div
      className={`relative overflow-hidden ${className || ""}`}
      data-image-id={props.id || Math.random().toString(36).substring(2, 9)}
    >
      {lowQualitySrc && !isLoaded && (
        <Image
          src={lowQualitySrc || "/placeholder.svg"}
          alt={alt}
          fill={props.fill}
          width={props.width}
          height={props.height}
          className={`transition-opacity duration-500 ${isLoaded ? "opacity-0" : "opacity-100"}`}
          style={{ objectFit: props.style?.objectFit || "cover" }}
          priority={false}
        />
      )}

      {isInView && (
        <Image
          src={src || "/placeholder.svg"}
          alt={alt}
          fill={props.fill}
          width={props.width}
          height={props.height}
          className={`transition-opacity duration-500 ${isLoaded ? "opacity-100" : "opacity-0"}`}
          style={props.style}
          onLoad={() => setIsLoaded(true)}
          loading="lazy"
          {...props}
        />
      )}
    </div>
  )
}
