"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X, LogIn, UserPlus } from "lucide-react"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import { ThemeToggle } from "@/components/theme-toggle"
import { useTheme } from "next-themes"

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { theme } = useTheme()
  const menuRef = useRef<HTMLDivElement>(null)
  const menuButtonRef = useRef<HTMLButtonElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    // Handle keyboard navigation and close menu when clicking outside
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current &&
        !menuRef.current.contains(event.target as Node) &&
        menuButtonRef.current &&
        !menuButtonRef.current.contains(event.target as Node)
      ) {
        setIsMenuOpen(false)
      }
    }

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        setIsMenuOpen(false)
      }
    }

    document.addEventListener("mousedown", handleClickOutside)
    document.addEventListener("keydown", handleEscape)

    return () => {
      document.removeEventListener("mousedown", handleClickOutside)
      document.removeEventListener("keydown", handleEscape)
    }
  }, [])

  const handleSignIn = () => {
    // In a real app, this would navigate to a sign-in page or open a modal
    alert("Sign In functionality would be implemented here")
  }

  const handleJoinNow = () => {
    // In a real app, this would navigate to a registration page
    alert("Registration functionality would be implemented here")
  }

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300 theme-transition",
        scrolled ? "bg-background/90 backdrop-blur-md shadow-md" : "bg-transparent",
      )}
      role="navigation"
      aria-label="Main navigation"
    >
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-primary/5 to-accent/5 opacity-0"
        animate={{
          opacity: scrolled ? 1 : 0,
        }}
        transition={{ duration: 0.5 }}
      />

      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center group" aria-label="ROOH Home">
            <motion.div
              className="h-10 w-10 relative transition-transform duration-300 group-hover:scale-110"
              whileHover={{ rotate: [0, -5, 5, 0] }}
              transition={{ duration: 0.5 }}
            >
              <Image src="/logo.png" alt="" fill className="object-contain" priority />
            </motion.div>
            <motion.span
              className="font-bold text-xl tracking-wide text-foreground ml-2 transition-colors duration-300 group-hover:text-primary"
              whileHover={{
                textShadow: "0 0 8px rgba(var(--primary) / 0.3)",
              }}
            >
              <span className="text-primary">R</span>OOH
            </motion.span>
          </Link>

          {/* Desktop navigation */}
          <div className="hidden md:flex items-center space-x-1" role="menubar">
            <Link
              href="#features"
              className="text-foreground/80 hover:text-foreground transition-colors px-3 py-2 rounded-md text-sm hover:bg-primary/10 relative overflow-hidden group focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
              role="menuitem"
            >
              <motion.span
                className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary"
                whileHover={{ width: "100%" }}
                transition={{ duration: 0.3 }}
              />
              Features
            </Link>
            <Link
              href="#how-it-works"
              className="text-foreground/80 hover:text-foreground transition-colors px-3 py-2 rounded-md text-sm hover:bg-primary/10 relative overflow-hidden group focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
              role="menuitem"
            >
              <motion.span
                className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary"
                whileHover={{ width: "100%" }}
                transition={{ duration: 0.3 }}
              />
              How It Works
            </Link>
            <Link
              href="#community"
              className="text-foreground/80 hover:text-foreground transition-colors px-3 py-2 rounded-md text-sm hover:bg-primary/10 relative overflow-hidden group focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
              role="menuitem"
            >
              <motion.span
                className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary"
                whileHover={{ width: "100%" }}
                transition={{ duration: 0.3 }}
              />
              Community
            </Link>
            <ThemeToggle />
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="ghost"
                className="ml-4 font-medium text-foreground hover:bg-primary/20 border-none group relative overflow-hidden focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
                onClick={handleSignIn}
                role="menuitem"
              >
                <motion.span
                  className="absolute inset-0 bg-primary/10 rounded-md"
                  initial={{ x: "-100%" }}
                  whileHover={{ x: "100%" }}
                  transition={{ duration: 0.5 }}
                />
                <LogIn
                  className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                  aria-hidden="true"
                />
                Sign In
              </Button>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                className="ml-2 font-medium bg-primary hover:bg-primary-light border-none text-primary-foreground group transition-transform duration-300 relative overflow-hidden focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
                onClick={handleJoinNow}
                role="menuitem"
              >
                <motion.span
                  className="absolute inset-0 bg-white/10 rounded-md"
                  initial={{ scale: 0, opacity: 0 }}
                  whileHover={{ scale: 1, opacity: 1 }}
                  transition={{ duration: 0.4 }}
                />
                <UserPlus
                  className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:scale-110"
                  aria-hidden="true"
                />
                Join Now
              </Button>
            </motion.div>
          </div>

          {/* Mobile menu button */}
          <div className="flex md:hidden items-center space-x-2">
            <ThemeToggle />
            <button
              type="button"
              className="text-foreground/80 hover:text-foreground transition-colors focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-expanded={isMenuOpen}
              aria-controls="mobile-menu"
              aria-label={isMenuOpen ? "Close menu" : "Open menu"}
              ref={menuButtonRef}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" aria-hidden="true" />
              ) : (
                <Menu className="h-6 w-6" aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile navigation */}
      <div
        id="mobile-menu"
        ref={menuRef}
        className={cn(
          "md:hidden transition-all duration-300 ease-in-out",
          isMenuOpen ? "max-h-64" : "max-h-0 overflow-hidden",
        )}
        role="menu"
        aria-labelledby="mobile-menu-button"
      >
        <div className="px-2 pt-2 pb-4 space-y-1 bg-background/95 backdrop-blur-md">
          <Link
            href="#features"
            className="text-foreground/80 hover:text-foreground block px-3 py-2 rounded-md text-base hover:bg-primary/10 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
            onClick={() => setIsMenuOpen(false)}
            role="menuitem"
          >
            Features
          </Link>
          <Link
            href="#how-it-works"
            className="text-foreground/80 hover:text-foreground block px-3 py-2 rounded-md text-base hover:bg-primary/10 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
            onClick={() => setIsMenuOpen(false)}
            role="menuitem"
          >
            How It Works
          </Link>
          <Link
            href="#community"
            className="text-foreground/80 hover:text-foreground block px-3 py-2 rounded-md text-base hover:bg-primary/10 focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
            onClick={() => setIsMenuOpen(false)}
            role="menuitem"
          >
            Community
          </Link>
          <div className="pt-4 flex flex-col space-y-2">
            <Button
              variant="ghost"
              className="w-full font-medium text-foreground hover:bg-primary/20 border-none group focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
              onClick={() => {
                handleSignIn()
                setIsMenuOpen(false)
              }}
              role="menuitem"
            >
              <LogIn
                className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1"
                aria-hidden="true"
              />
              Sign In
            </Button>
            <Button
              className="w-full font-medium bg-primary hover:bg-primary-light border-none text-primary-foreground group focus:ring-2 focus:ring-primary focus:ring-offset-2 focus:ring-offset-background"
              onClick={() => {
                handleJoinNow()
                setIsMenuOpen(false)
              }}
              role="menuitem"
            >
              <UserPlus
                className="mr-2 h-4 w-4 transition-transform duration-300 group-hover:scale-110"
                aria-hidden="true"
              />
              Join Now
            </Button>
          </div>
        </div>
      </div>
    </motion.nav>
  )
}
