"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Play, Pause, SkipBack, Volume2, Clock, Heart } from "lucide-react"
import { motion } from "framer-motion"

const exercises = [
  {
    title: "Calming Breath",
    duration: "5 minutes",
    description: "A gentle breathing exercise to reduce anxiety",
    favorite: true,
  },
  {
    title: "Present Moment",
    duration: "10 minutes",
    description: "Grounding technique for stress relief",
    favorite: false,
  },
  {
    title: "Body Scan",
    duration: "15 minutes",
    description: "Progressive relaxation for tension release",
    favorite: true,
  },
]

export default function Mindfulness() {
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentExercise, setCurrentExercise] = useState(0)
  const [progress, setProgress] = useState(0)

  const togglePlay = () => {
    setIsPlaying(!isPlaying)

    // Simulate progress
    if (!isPlaying) {
      const interval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval)
            setIsPlaying(false)
            return 0
          }
          return prev + 1
        })
      }, 300) // faster for demo purposes

      return () => clearInterval(interval)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="rounded-2xl shadow-card overflow-hidden bg-card border border-border"
    >
      <div className="bg-gradient-to-r from-primary to-primary-dark px-6 py-4">
        <h3 className="text-white text-lg font-medium">Guided Mindfulness</h3>
        <p className="text-slate-200 text-sm">Calming exercises for mental clarity</p>
      </div>

      <div className="p-6">
        <div className="bg-background/50 p-4 rounded-lg mb-6 border border-border">
          <div className="flex justify-between items-center mb-4">
            <div>
              <h4 className="font-medium text-card-foreground">{exercises[currentExercise].title}</h4>
              <div className="flex items-center text-sm text-card-foreground/70">
                <Clock className="w-3 h-3 mr-1" />
                {exercises[currentExercise].duration}
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className={`${
                exercises[currentExercise].favorite
                  ? "text-accent"
                  : "text-card-foreground/70 hover:text-card-foreground"
              }`}
            >
              <Heart className="h-5 w-5" />
            </Button>
          </div>

          <div className="h-2 bg-background rounded-full mb-4">
            <div
              className="h-full bg-primary rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>

          <div className="flex justify-between items-center">
            <Button
              variant="ghost"
              size="icon"
              className="text-card-foreground hover:text-primary hover:bg-primary/10"
              onClick={() => {
                setCurrentExercise((prev) => (prev - 1 + exercises.length) % exercises.length)
                setProgress(0)
                setIsPlaying(false)
              }}
            >
              <SkipBack className="h-5 w-5" />
            </Button>

            <Button
              size="lg"
              className="rounded-full h-14 w-14 bg-primary hover:bg-primary-light shadow-glow"
              onClick={togglePlay}
            >
              {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6 ml-1" />}
            </Button>

            <Button variant="ghost" size="icon" className="text-card-foreground hover:text-primary hover:bg-primary/10">
              <Volume2 className="h-5 w-5" />
            </Button>
          </div>
        </div>

        <div className="space-y-3">
          <h4 className="font-medium text-card-foreground mb-2">More Exercises</h4>

          {exercises.map((exercise, index) => (
            <button
              key={index}
              className={`w-full text-left p-3 rounded-lg border ${
                currentExercise === index
                  ? "border-primary bg-primary/10"
                  : "border-border hover:border-primary/50 hover:bg-background/50"
              } transition-colors`}
              onClick={() => {
                setCurrentExercise(index)
                setProgress(0)
                setIsPlaying(false)
              }}
            >
              <div className="flex justify-between">
                <h5 className="font-medium text-card-foreground">{exercise.title}</h5>
                <span className="text-sm text-card-foreground/70">{exercise.duration}</span>
              </div>
              <p className="text-sm text-card-foreground/80 truncate">{exercise.description}</p>
            </button>
          ))}
        </div>
      </div>
    </motion.div>
  )
}
