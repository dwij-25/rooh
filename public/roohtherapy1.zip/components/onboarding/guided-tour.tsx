"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { X, ArrowRight, Check } from "lucide-react"
import { Button } from "@/components/ui/button"

type TourStep = {
  target: string
  title: string
  content: string
  position: "top" | "bottom" | "left" | "right"
}

const tourSteps: TourStep[] = [
  {
    target: "#mood-tracker",
    title: "Track Your Mood",
    content:
      "Monitor your emotional patterns with our private mood tracker. Log your feelings daily to identify patterns.",
    position: "left",
  },
  {
    target: "#journal",
    title: "Express Yourself",
    content: "Document your thoughts and feelings in a secure digital journal. Your entries are private and encrypted.",
    position: "right",
  },
  {
    target: "#mindfulness",
    title: "Practice Mindfulness",
    content: "Access guided exercises designed specifically for introverts to help you find calm and clarity.",
    position: "left",
  },
  {
    target: "#community",
    title: "Connect Anonymously",
    content: "Share experiences and find support in our community board without revealing your identity.",
    position: "top",
  },
]

export default function GuidedTour() {
  const [isFirstVisit, setIsFirstVisit] = useState(false)
  const [currentStep, setCurrentStep] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [targetElement, setTargetElement] = useState<HTMLElement | null>(null)
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 })

  useEffect(() => {
    // Check if this is the user's first visit
    const hasVisited = localStorage.getItem("rooh_has_visited")
    if (!hasVisited) {
      setIsFirstVisit(true)
      setIsVisible(true)
      localStorage.setItem("rooh_has_visited", "true")
    }
  }, [])

  useEffect(() => {
    if (!isVisible) return

    const step = tourSteps[currentStep]
    const element = document.querySelector(step.target) as HTMLElement

    if (element) {
      setTargetElement(element)

      // Calculate position based on element's bounding rect
      const rect = element.getBoundingClientRect()
      const scrollTop = window.scrollY || document.documentElement.scrollTop
      const scrollLeft = window.scrollX || document.documentElement.scrollLeft

      let top = 0
      let left = 0

      switch (step.position) {
        case "top":
          top = rect.top + scrollTop - 10 - 150 // tooltip height
          left = rect.left + scrollLeft + rect.width / 2 - 150 // half tooltip width
          break
        case "bottom":
          top = rect.bottom + scrollTop + 10
          left = rect.left + scrollLeft + rect.width / 2 - 150
          break
        case "left":
          top = rect.top + scrollTop + rect.height / 2 - 75
          left = rect.left + scrollLeft - 10 - 300
          break
        case "right":
          top = rect.top + scrollTop + rect.height / 2 - 75
          left = rect.right + scrollLeft + 10
          break
      }

      setTooltipPosition({ top, left })

      // Scroll to the element
      element.scrollIntoView({ behavior: "smooth", block: "center" })

      // Highlight the element
      element.classList.add("tour-highlight")

      return () => {
        element.classList.remove("tour-highlight")
      }
    }
  }, [currentStep, isVisible])

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      handleClose()
    }
  }

  const handleClose = () => {
    setIsVisible(false)
    // Remove any remaining highlights
    document.querySelectorAll(".tour-highlight").forEach((el) => {
      el.classList.remove("tour-highlight")
    })
  }

  if (!isFirstVisit || !isVisible) return null

  return (
    <>
      {/* Overlay */}
      <div className="fixed inset-0 bg-black/50 z-40" onClick={handleClose} aria-hidden="true" />

      {/* Tooltip */}
      <AnimatePresence>
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
          className="fixed z-50 w-[300px] bg-card rounded-lg shadow-lg p-4 border border-border"
          style={{
            top: `${tooltipPosition.top}px`,
            left: `${tooltipPosition.left}px`,
          }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="tour-title"
        >
          <button
            onClick={handleClose}
            className="absolute top-2 right-2 text-foreground/70 hover:text-foreground"
            aria-label="Close tour"
          >
            <X size={16} />
          </button>

          <h3 id="tour-title" className="text-lg font-semibold mb-2 text-foreground">
            {tourSteps[currentStep].title}
          </h3>

          <p className="text-foreground/80 mb-4">{tourSteps[currentStep].content}</p>

          <div className="flex items-center justify-between">
            <div className="flex space-x-1">
              {tourSteps.map((_, index) => (
                <span
                  key={index}
                  className={`block w-2 h-2 rounded-full ${index === currentStep ? "bg-primary" : "bg-primary/30"}`}
                  aria-hidden="true"
                />
              ))}
            </div>

            <Button
              size="sm"
              onClick={handleNext}
              className="bg-primary hover:bg-primary-light text-primary-foreground"
            >
              {currentStep < tourSteps.length - 1 ? (
                <>
                  Next <ArrowRight className="ml-1 h-4 w-4" />
                </>
              ) : (
                <>
                  Got it <Check className="ml-1 h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </motion.div>
      </AnimatePresence>
    </>
  )
}
