"use client"

import type React from "react"
import Link from "next/link"
import Image from "next/image"
import { Heart, Mail, Twitter, Instagram, Facebook, Github, ExternalLink, Coffee, BookOpen } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { useState } from "react"

export default function Footer() {
  const { theme } = useTheme()
  const [email, setEmail] = useState("")

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault()
    // In a real app, this would submit to a newsletter service
    alert(`Thank you for subscribing with ${email}!`)
    setEmail("")
  }

  return (
    <footer className="bg-background border-t border-border text-foreground py-16 theme-transition">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="space-y-6">
            <div className="flex items-center">
              <div className="h-12 w-12 relative mr-2 transition-transform duration-300 hover:scale-110">
                <Image src="/logo.png" alt="ROOH Logo" fill className="object-contain" />
              </div>
              <h2 className="text-2xl font-bold">
                <span className="text-primary">R</span>OOH
              </h2>
            </div>
            <p className="text-foreground/80 max-w-xs">
              A safe, anonymous space for introverts to heal, grow, and connect at their own pace.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-foreground/70 hover:text-primary transition-colors" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-foreground/70 hover:text-primary transition-colors" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-foreground/70 hover:text-primary transition-colors" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-foreground/70 hover:text-primary transition-colors" aria-label="Github">
                <Github className="h-5 w-5" />
              </Link>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-6 text-foreground">Platform</h3>
            <ul className="space-y-4">
              <li>
                <Link
                  href="#features"
                  className="text-foreground/70 hover:text-primary transition-colors flex items-center"
                >
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Features
                </Link>
              </li>
              <li>
                <Link
                  href="#how-it-works"
                  className="text-foreground/70 hover:text-primary transition-colors flex items-center"
                >
                  <ExternalLink className="h-3 w-3 mr-2" />
                  How It Works
                </Link>
              </li>
              <li>
                <Link href="#" className="text-foreground/70 hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Testimonials
                </Link>
              </li>
              <li>
                <Link
                  href="/privacy"
                  className="text-foreground/70 hover:text-primary transition-colors flex items-center"
                >
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  href="/terms"
                  className="text-foreground/70 hover:text-primary transition-colors flex items-center"
                >
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-6 text-foreground">Resources</h3>
            <ul className="space-y-4">
              <li>
                <Link href="#" className="text-foreground/70 hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Blog
                </Link>
              </li>
              <li>
                <Link href="#" className="text-foreground/70 hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Mental Health Tips
                </Link>
              </li>
              <li>
                <Link href="#" className="text-foreground/70 hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Introvert's Guide
                </Link>
              </li>
              <li>
                <Link href="#" className="text-foreground/70 hover:text-primary transition-colors flex items-center">
                  <ExternalLink className="h-3 w-3 mr-2" />
                  Crisis Resources
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-medium mb-6 text-foreground">Subscribe</h3>
            <p className="text-foreground/80 mb-4">
              Join our newsletter to stay up to date with mental health tips and resources.
            </p>
            <form onSubmit={handleSubscribe} className="space-y-3">
              <div className="flex">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 px-4 py-2 rounded-l-md bg-background border border-border focus:outline-none focus:ring-2 focus:ring-primary"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  aria-label="Email address"
                />
                <Button
                  type="submit"
                  className="rounded-l-none bg-primary hover:bg-primary-light text-primary-foreground"
                  aria-label="Subscribe"
                >
                  <Mail className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-foreground/60">We respect your privacy. Unsubscribe at any time.</p>
            </form>
          </div>
        </div>

        {/* Support ROOH Section */}
        <div className="mt-16 pt-8 border-t border-border">
          <h3 className="text-xl font-semibold text-center mb-6">Support ROOH</h3>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="bg-card p-6 rounded-xl border border-border">
              <div className="flex items-center mb-4">
                <Coffee className="h-6 w-6 text-primary mr-3" />
                <h4 className="text-lg font-medium">Buy Us a Coffee</h4>
              </div>
              <p className="text-foreground/80 mb-4">
                ROOH is a free service maintained by volunteers. Your support helps us keep the servers running and
                develop new features.
              </p>
              <div className="flex space-x-3">
                <a
                  href="https://www.buymeacoffee.com/roohtherapy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary hover:bg-primary-light text-primary-foreground px-4 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Buy Me a Coffee
                </a>
                <a
                  href="https://www.patreon.com/roohtherapy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-background hover:bg-primary/10 text-foreground border border-primary px-4 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  Become a Patron
                </a>
              </div>
            </div>

            <div className="bg-card p-6 rounded-xl border border-border">
              <div className="flex items-center mb-4">
                <BookOpen className="h-6 w-6 text-primary mr-3" />
                <h4 className="text-lg font-medium">Recommended Resources</h4>
              </div>
              <p className="text-foreground/80 mb-4">
                These books have helped many in their mental health journey. We receive a small commission from
                purchases made through these links.
              </p>
              <ul className="space-y-2 text-sm">
                <li className="flex items-start">
                  <ExternalLink className="h-4 w-4 text-primary mr-2 mt-0.5" />
                  <a
                    href="https://amzn.to/rooh-quiet"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-foreground hover:text-primary transition-colors"
                  >
                    Quiet: The Power of Introverts in a World That Can't Stop Talking
                  </a>
                </li>
                <li className="flex items-start">
                  <ExternalLink className="h-4 w-4 text-primary mr-2 mt-0.5" />
                  <a
                    href="https://amzn.to/rooh-anxiety"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-foreground hover:text-primary transition-colors"
                  >
                    Unwinding Anxiety: New Science Shows How to Break the Cycles of Worry and Fear
                  </a>
                </li>
                <li className="flex items-start">
                  <ExternalLink className="h-4 w-4 text-primary mr-2 mt-0.5" />
                  <a
                    href="https://amzn.to/rooh-mindfulness"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-foreground hover:text-primary transition-colors"
                  >
                    The Mindful Way Through Depression: Freeing Yourself from Chronic Unhappiness
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>

        <div className="border-t border-border mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-foreground/60 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} ROOH. All rights reserved.
          </p>
          <div className="flex items-center">
            <p className="text-foreground/60 text-sm">Made with</p>
            <Heart className="h-4 w-4 text-primary mx-1 animate-pulse" />
            <p className="text-foreground/60 text-sm">for introverts everywhere</p>
          </div>
        </div>
      </div>
    </footer>
  )
}
