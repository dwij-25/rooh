"use client"

import { Button } from "@/components/ui/button"
import { MessageSquare, ThumbsUp, Clock, Users } from "lucide-react"
import { motion } from "framer-motion"

const posts = [
  {
    id: 1,
    tag: "Anxiety",
    title: "How do you handle social gatherings?",
    content:
      "I find large gatherings extremely draining. I've tried preparing in advance, but still feel overwhelmed. Any coping strategies from fellow introverts?",
    comments: 12,
    likes: 24,
    timeAgo: "2 hours ago",
  },
  {
    id: 2,
    tag: "Self-Care",
    title: "Daily mindfulness practice changed my life",
    content:
      "I've been practicing mindfulness for just 5 minutes every morning for the past month. The difference in my anxiety levels is remarkable. Wanted to share this small win!",
    comments: 8,
    likes: 37,
    timeAgo: "5 hours ago",
  },
  {
    id: 3,
    tag: "Discussion",
    title: "Books that helped your mental health journey",
    content:
      "I'm looking for book recommendations that have genuinely helped others with anxiety, depression, or personal growth. Fiction or non-fiction welcome.",
    comments: 19,
    likes: 15,
    timeAgo: "1 day ago",
  },
]

export default function Community() {
  return (
    <section id="community" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl font-bold text-foreground mb-4">Anonymous Community</h2>
          <p className="text-foreground/80">
            Connect with others who understand, share experiences, and find support without revealing your identity.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-card rounded-2xl shadow-card overflow-hidden border border-border max-w-5xl mx-auto"
        >
          <div className="bg-gradient-to-r from-primary to-primary-dark px-6 py-4 flex justify-between items-center">
            <div>
              <h3 className="text-primary-foreground text-lg font-medium">Community Board</h3>
              <div className="flex items-center text-primary-foreground/80 text-sm">
                <Users className="w-4 h-4 mr-1" />
                <span>1,243 members online</span>
              </div>
            </div>
            <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
              <MessageSquare className="h-4 w-4 mr-2" />
              New Post
            </Button>
          </div>

          <div className="divide-y divide-border">
            {posts.map((post) => (
              <div key={post.id} className="p-6 hover:bg-background/30 transition-colors">
                <div className="flex items-start mb-3">
                  <div className="bg-primary/20 text-primary text-xs font-medium px-2.5 py-1 rounded-full mr-2">
                    {post.tag}
                  </div>
                  <h4 className="font-medium text-lg text-card-foreground">{post.title}</h4>
                </div>
                <p className="text-card-foreground/80 mb-4">{post.content}</p>
                <div className="flex items-center text-sm text-card-foreground/70">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-card-foreground hover:text-primary hover:bg-primary/10 mr-4"
                  >
                    <ThumbsUp className="h-4 w-4 mr-1" />
                    {post.likes}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-card-foreground hover:text-primary hover:bg-primary/10 mr-4"
                  >
                    <MessageSquare className="h-4 w-4 mr-1" />
                    {post.comments}
                  </Button>
                  <div className="flex items-center ml-auto">
                    <Clock className="h-3 w-3 mr-1" />
                    <span>{post.timeAgo}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-6 text-center border-t border-border">
            <Button variant="outline" className="text-primary border-primary hover:bg-primary/10">
              View More Posts
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
