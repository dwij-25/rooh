import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import Script from "next/script"

const inter = Inter({ subsets: ["latin"], display: "swap" })

export const metadata: Metadata = {
  title: "ROOH - Safe Space for Introverts",
  description:
    "A safe, anonymous space for introverts to heal, grow, and connect at their own pace. Access free mental health tools, mood tracking, journaling, and community support.",
  keywords:
    "mental health, introverts, anonymous therapy, mood tracking, journaling, mindfulness, community support, anxiety, depression, self-care",
  authors: [{ name: "ROOH Team" }],
  creator: "ROOH",
  publisher: "ROOH",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://v0-roohtherapy1-theta.vercel.app"),
  alternates: {
    canonical: "/",
  },
  openGraph: {
    title: "ROOH - Safe Space for Introverts",
    description: "A safe, anonymous space for introverts to heal, grow, and connect at their own pace.",
    url: "https://v0-roohtherapy1-theta.vercel.app",
    siteName: "ROOH",
    images: [
      {
        url: "/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "ROOH - Safe Space for Introverts",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ROOH - Safe Space for Introverts",
    description: "A safe, anonymous space for introverts to heal, grow, and connect at their own pace.",
    images: ["/og-image.jpg"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
        <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
        <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
        <link rel="manifest" href="/site.webmanifest" />
        <meta name="theme-color" content="#3A3E6C" />
      </head>
      <body className={`${inter.className} theme-transition`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          <a
            href="#main-content"
            className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:p-4 focus:bg-background focus:text-foreground"
          >
            Skip to main content
          </a>
          {children}
        </ThemeProvider>

        {/* Lightweight analytics - Plausible */}
        <Script
          data-domain="v0-roohtherapy1-theta.vercel.app"
          src="https://plausible.io/js/script.js"
          strategy="lazyOnload"
        />
      </body>
    </html>
  )
}
