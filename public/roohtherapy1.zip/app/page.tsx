"use client"

import { useEffect, Suspense } from "react"
import dynamic from "next/dynamic"
import Navbar from "@/components/navbar"
import Hero from "@/components/hero"
import Features from "@/components/features"
import Footer from "@/components/footer"
import { useTheme } from "next-themes"
import GuidedTour from "@/components/onboarding/guided-tour"
import ProgressIndicator from "@/components/dashboard/progress-indicator"

// Lazy load non-critical components
const BackgroundAnimation = dynamic(() => import("@/components/background-animation"), {
  ssr: false,
  loading: () => <div className="fixed inset-0 bg-background" />,
})

const WelcomeAnimation = dynamic(() => import("@/components/welcome-animation"), {
  ssr: false,
})

const ColorThemeShowcase = dynamic(() => import("@/components/color-theme-showcase"), {
  loading: () => <div className="py-16 bg-background border-y border-border" />,
})

const ChatPreview = dynamic(() => import("@/components/chat-preview"), {
  loading: () => <div className="h-64 rounded-2xl bg-card animate-pulse" />,
})

const MoodTracker = dynamic(() => import("@/components/mood-tracker"), {
  loading: () => <div className="h-64 rounded-2xl bg-card animate-pulse" />,
})

const Journal = dynamic(() => import("@/components/journal"), {
  loading: () => <div className="h-64 rounded-2xl bg-card animate-pulse" />,
})

const Mindfulness = dynamic(() => import("@/components/mindfulness"), {
  loading: () => <div className="h-64 rounded-2xl bg-card animate-pulse" />,
})

const Community = dynamic(() => import("@/components/community"), {
  loading: () => <div className="py-20 bg-background" />,
})

export default function Home() {
  const { theme, setTheme } = useTheme()

  // Ensure theme is set on initial load
  useEffect(() => {
    // Default to dark theme to show the new green palette
    if (!theme) {
      setTheme("dark")
    }
  }, [theme, setTheme])

  return (
    <div className="relative min-h-screen overflow-hidden bg-background theme-transition">
      <WelcomeAnimation />
      <BackgroundAnimation />
      <div className="relative z-10">
        <Navbar />
        <main id="main-content" tabIndex={-1}>
          <Hero />
          <Features />
          <ColorThemeShowcase />

          <section className="container mx-auto px-4 py-16">
            <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Your Personal Wellness Tools</h2>

            <div className="grid gap-8 md:gap-16 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <div className="grid gap-8 md:grid-cols-2">
                  <div id="mood-tracker">
                    <Suspense fallback={<div className="h-64 rounded-2xl bg-card animate-pulse" />}>
                      <MoodTracker />
                    </Suspense>
                  </div>
                  <div id="chat-preview">
                    <Suspense fallback={<div className="h-64 rounded-2xl bg-card animate-pulse" />}>
                      <ChatPreview />
                    </Suspense>
                  </div>
                </div>
              </div>

              <div>
                <ProgressIndicator />
              </div>
            </div>

            <div className="grid gap-8 md:grid-cols-2 mt-16">
              <div id="journal">
                <Suspense fallback={<div className="h-64 rounded-2xl bg-card animate-pulse" />}>
                  <Journal />
                </Suspense>
              </div>
              <div id="mindfulness">
                <Suspense fallback={<div className="h-64 rounded-2xl bg-card animate-pulse" />}>
                  <Mindfulness />
                </Suspense>
              </div>
            </div>
          </section>

          <Community />
        </main>
        <Footer />
        <GuidedTour />
      </div>
    </div>
  )
}
